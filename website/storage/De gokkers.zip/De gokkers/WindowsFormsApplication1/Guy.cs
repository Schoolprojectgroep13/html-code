﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    public class Guy
    {
        public string name;  // De naam van de gokker
        public Bet mybet;    // Een instantie van Bet()
        public int cash;     // Het saldo van de gokker

        //Deze twee velden zijn de gokkers GUI controls op het formulier
        public RadioButton myradiobutton;
        public TextBox mytextbox;

        
        public void UpdateLabels()
        {
            //Verander mijn label in de omschrijving van mijn weddenschap.
            if (mybet == null)
            {
                mytextbox.Text = name + " heeft geen bods geplaatst.";
            }
            else
            {
                mytextbox.Text = mybet.GetDescription();
            }
            //Verander de label op mijn radioknop zodat deze mijn saldo laat zien.

            //(Bijv. “Lidy heeft 43 euro.”)

        }

        public bool PlaceBet(int Amount, int ant)
        {
            //Plaats een nieuwe weddenschap en sla het op in de variabele MyBet.
            this.mybet = new Bet();
            //Retourneer een true als de gokker genoeg geld heeft om te wedden.

            if (cash >= Amount)
            {
                cash = cash - Amount;
                //MyTextBox = new TextBox();
                mybet.amount = Amount;
                mybet.ant = ant;
                mybet.bettor = this;
                UpdateLabels();
                return true;
            }
            else
            {
                return false;
            }
            //Onderstaande regel staat er tijdelijk om foutmeldingen te voorkomen. 

            //Haal deze regel later weg.

        }

        public void ClearBet()
        {
            //Maak de weddenschap leeg.
            mybet = null;

        }

        public void Collect(int Winner)
        {
            //Betaal mijn weddenschap uit.
            if (mybet != null)
            {
                cash += mybet.PayOut(Winner);
            }
            //Maak mijn weddenschap leeg.
            mybet = null;
            //Werk mijn labels bij.
            UpdateLabels();
        }
    }
}
