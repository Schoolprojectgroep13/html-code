﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public class Ant
    {
        public int racetracklength;             //De lengte van de renbaan
        public PictureBox mypicturebox = null;
        public Random randomizer;               //Een instantie van Random (= Willekeurig) 
        public int startingposition;            //Hier begint de renbaan
        public int location = 0;                //De location van de mier op de renbaan
        //public int dead = 4;                  //Max van mieren die dood kunnnen
        
        public Ant()
        {
        }

        public bool Run()
        {
            //Ga willekeurig 1, 2, 3 of 4 posities naar voren.
            int moveforward = randomizer.Next(1, 4);
            //Mieren die doodgaan op een willekeurig moment
            
            //Werk de positie van PictureBox bij op het formulier.
            Point p = mypicturebox.Location;
            p.X += moveforward;
            mypicturebox.Location = p;
            //Geef de waarde ‘true’ terug als ik de race win.
            if (p.X >= (racetracklength - 50))
                {
                    return true;
                }
                else
                {
                    return false;
                }
        }

        public void TakeStartingPosition()
        {
            //Wijzig mijn locatie naar de startlijn.   

            startingposition = 0;
        }
    }
}
