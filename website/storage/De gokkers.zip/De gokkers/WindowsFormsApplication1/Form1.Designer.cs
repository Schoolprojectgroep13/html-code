﻿namespace WindowsFormsApplication1
{
    partial class DeGokkersWidow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeGokkersWidow));
            this.Picturebox = new System.Windows.Forms.PictureBox();
            this.GambleCornerGroup = new System.Windows.Forms.GroupBox();
            this.BetButton = new System.Windows.Forms.Button();
            this.NumericAnt = new System.Windows.Forms.NumericUpDown();
            this.NumericEuro = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.MinimalLabel = new System.Windows.Forms.Label();
            this.Radiobutton3 = new System.Windows.Forms.RadioButton();
            this.Radiobutton2 = new System.Windows.Forms.RadioButton();
            this.Radiobutton1 = new System.Windows.Forms.RadioButton();
            this.ParticipantsLabel = new System.Windows.Forms.Label();
            this.InfoGroup = new System.Windows.Forms.GroupBox();
            this.ResetButton = new System.Windows.Forms.Button();
            this.GoButton = new System.Windows.Forms.Button();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.GamblesLabel = new System.Windows.Forms.Label();
            this.Ant1img = new System.Windows.Forms.PictureBox();
            this.Ant2img = new System.Windows.Forms.PictureBox();
            this.Ant3img = new System.Windows.Forms.PictureBox();
            this.Ant4img = new System.Windows.Forms.PictureBox();
            this.Ant5img = new System.Windows.Forms.PictureBox();
            this.Ant6img = new System.Windows.Forms.PictureBox();
            this.Ant7img = new System.Windows.Forms.PictureBox();
            this.Ant8img = new System.Windows.Forms.PictureBox();
            this.Ant9img = new System.Windows.Forms.PictureBox();
            this.Ant10img = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Picturebox)).BeginInit();
            this.GambleCornerGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumericAnt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericEuro)).BeginInit();
            this.InfoGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ant1img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant2img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant3img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant4img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant5img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant6img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant7img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant8img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant9img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant10img)).BeginInit();
            this.SuspendLayout();
            // 
            // Picturebox
            // 
            this.Picturebox.Image = ((System.Drawing.Image)(resources.GetObject("Picturebox.Image")));
            this.Picturebox.Location = new System.Drawing.Point(29, 15);
            this.Picturebox.Name = "Picturebox";
            this.Picturebox.Size = new System.Drawing.Size(599, 515);
            this.Picturebox.TabIndex = 0;
            this.Picturebox.TabStop = false;
            // 
            // GambleCornerGroup
            // 
            this.GambleCornerGroup.Controls.Add(this.BetButton);
            this.GambleCornerGroup.Controls.Add(this.NumericAnt);
            this.GambleCornerGroup.Controls.Add(this.NumericEuro);
            this.GambleCornerGroup.Controls.Add(this.label2);
            this.GambleCornerGroup.Controls.Add(this.Label1);
            this.GambleCornerGroup.Controls.Add(this.MinimalLabel);
            this.GambleCornerGroup.Controls.Add(this.Radiobutton3);
            this.GambleCornerGroup.Controls.Add(this.Radiobutton2);
            this.GambleCornerGroup.Controls.Add(this.Radiobutton1);
            this.GambleCornerGroup.Controls.Add(this.ParticipantsLabel);
            this.GambleCornerGroup.Location = new System.Drawing.Point(635, 13);
            this.GambleCornerGroup.Name = "GambleCornerGroup";
            this.GambleCornerGroup.Size = new System.Drawing.Size(375, 281);
            this.GambleCornerGroup.TabIndex = 1;
            this.GambleCornerGroup.TabStop = false;
            this.GambleCornerGroup.Text = "Gamble corner";
            // 
            // BetButton
            // 
            this.BetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.BetButton.Location = new System.Drawing.Point(127, 228);
            this.BetButton.Name = "BetButton";
            this.BetButton.Size = new System.Drawing.Size(119, 33);
            this.BetButton.TabIndex = 9;
            this.BetButton.Text = "Bet";
            this.BetButton.UseVisualStyleBackColor = true;
            this.BetButton.Click += new System.EventHandler(this.BetButton_Click);
            // 
            // NumericAnt
            // 
            this.NumericAnt.Location = new System.Drawing.Point(252, 188);
            this.NumericAnt.Name = "NumericAnt";
            this.NumericAnt.Size = new System.Drawing.Size(41, 20);
            this.NumericAnt.TabIndex = 8;
            // 
            // NumericEuro
            // 
            this.NumericEuro.Location = new System.Drawing.Point(62, 188);
            this.NumericEuro.Name = "NumericEuro";
            this.NumericEuro.Size = new System.Drawing.Size(41, 20);
            this.NumericEuro.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(109, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "euro on ant number:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label1.Location = new System.Drawing.Point(7, 188);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(57, 17);
            this.Label1.TabIndex = 5;
            this.Label1.Text = "Gamble";
            // 
            // MinimalLabel
            // 
            this.MinimalLabel.AutoSize = true;
            this.MinimalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.MinimalLabel.Location = new System.Drawing.Point(0, 158);
            this.MinimalLabel.Name = "MinimalLabel";
            this.MinimalLabel.Size = new System.Drawing.Size(118, 26);
            this.MinimalLabel.TabIndex = 4;
            this.MinimalLabel.Text = "Minimal €5";
            // 
            // Radiobutton3
            // 
            this.Radiobutton3.AutoSize = true;
            this.Radiobutton3.Location = new System.Drawing.Point(7, 117);
            this.Radiobutton3.Name = "Radiobutton3";
            this.Radiobutton3.Size = new System.Drawing.Size(55, 17);
            this.Radiobutton3.TabIndex = 3;
            this.Radiobutton3.TabStop = true;
            this.Radiobutton3.Text = "Fedde";
            this.Radiobutton3.UseVisualStyleBackColor = true;
            this.Radiobutton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // Radiobutton2
            // 
            this.Radiobutton2.AutoSize = true;
            this.Radiobutton2.Location = new System.Drawing.Point(7, 93);
            this.Radiobutton2.Name = "Radiobutton2";
            this.Radiobutton2.Size = new System.Drawing.Size(49, 17);
            this.Radiobutton2.TabIndex = 2;
            this.Radiobutton2.TabStop = true;
            this.Radiobutton2.Text = "Elton";
            this.Radiobutton2.UseVisualStyleBackColor = true;
            this.Radiobutton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // Radiobutton1
            // 
            this.Radiobutton1.AutoSize = true;
            this.Radiobutton1.Location = new System.Drawing.Point(7, 69);
            this.Radiobutton1.Name = "Radiobutton1";
            this.Radiobutton1.Size = new System.Drawing.Size(54, 17);
            this.Radiobutton1.TabIndex = 1;
            this.Radiobutton1.TabStop = true;
            this.Radiobutton1.Text = "Sietse";
            this.Radiobutton1.UseVisualStyleBackColor = true;
            this.Radiobutton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // ParticipantsLabel
            // 
            this.ParticipantsLabel.AutoSize = true;
            this.ParticipantsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.ParticipantsLabel.Location = new System.Drawing.Point(7, 39);
            this.ParticipantsLabel.Name = "ParticipantsLabel";
            this.ParticipantsLabel.Size = new System.Drawing.Size(126, 26);
            this.ParticipantsLabel.TabIndex = 0;
            this.ParticipantsLabel.Text = "Participants";
            // 
            // InfoGroup
            // 
            this.InfoGroup.Controls.Add(this.ResetButton);
            this.InfoGroup.Controls.Add(this.GoButton);
            this.InfoGroup.Controls.Add(this.TextBox3);
            this.InfoGroup.Controls.Add(this.TextBox2);
            this.InfoGroup.Controls.Add(this.TextBox1);
            this.InfoGroup.Controls.Add(this.GamblesLabel);
            this.InfoGroup.Location = new System.Drawing.Point(635, 301);
            this.InfoGroup.Name = "InfoGroup";
            this.InfoGroup.Size = new System.Drawing.Size(375, 229);
            this.InfoGroup.TabIndex = 2;
            this.InfoGroup.TabStop = false;
            // 
            // ResetButton
            // 
            this.ResetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ResetButton.Location = new System.Drawing.Point(210, 186);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(83, 27);
            this.ResetButton.TabIndex = 5;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // GoButton
            // 
            this.GoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.GoButton.Location = new System.Drawing.Point(62, 180);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(119, 38);
            this.GoButton.TabIndex = 4;
            this.GoButton.Text = "Go!";
            this.GoButton.UseVisualStyleBackColor = true;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(5, 140);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(362, 20);
            this.TextBox3.TabIndex = 3;
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(6, 104);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(362, 20);
            this.TextBox2.TabIndex = 2;
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(7, 69);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(362, 20);
            this.TextBox1.TabIndex = 1;
            // 
            // GamblesLabel
            // 
            this.GamblesLabel.AutoSize = true;
            this.GamblesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.GamblesLabel.Location = new System.Drawing.Point(7, 20);
            this.GamblesLabel.Name = "GamblesLabel";
            this.GamblesLabel.Size = new System.Drawing.Size(100, 26);
            this.GamblesLabel.TabIndex = 0;
            this.GamblesLabel.Text = "Gambles";
            // 
            // Ant1img
            // 
            this.Ant1img.BackColor = System.Drawing.Color.Transparent;
            this.Ant1img.Image = ((System.Drawing.Image)(resources.GetObject("Ant1img.Image")));
            this.Ant1img.Location = new System.Drawing.Point(43, 25);
            this.Ant1img.Name = "Ant1img";
            this.Ant1img.Size = new System.Drawing.Size(55, 27);
            this.Ant1img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant1img.TabIndex = 3;
            this.Ant1img.TabStop = false;
            // 
            // Ant2img
            // 
            this.Ant2img.BackColor = System.Drawing.Color.Transparent;
            this.Ant2img.Image = ((System.Drawing.Image)(resources.GetObject("Ant2img.Image")));
            this.Ant2img.Location = new System.Drawing.Point(43, 72);
            this.Ant2img.Name = "Ant2img";
            this.Ant2img.Size = new System.Drawing.Size(55, 27);
            this.Ant2img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant2img.TabIndex = 4;
            this.Ant2img.TabStop = false;
            // 
            // Ant3img
            // 
            this.Ant3img.BackColor = System.Drawing.Color.Transparent;
            this.Ant3img.Image = ((System.Drawing.Image)(resources.GetObject("Ant3img.Image")));
            this.Ant3img.Location = new System.Drawing.Point(43, 124);
            this.Ant3img.Name = "Ant3img";
            this.Ant3img.Size = new System.Drawing.Size(55, 27);
            this.Ant3img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant3img.TabIndex = 5;
            this.Ant3img.TabStop = false;
            // 
            // Ant4img
            // 
            this.Ant4img.BackColor = System.Drawing.Color.Transparent;
            this.Ant4img.Image = ((System.Drawing.Image)(resources.GetObject("Ant4img.Image")));
            this.Ant4img.Location = new System.Drawing.Point(43, 174);
            this.Ant4img.Name = "Ant4img";
            this.Ant4img.Size = new System.Drawing.Size(55, 27);
            this.Ant4img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant4img.TabIndex = 6;
            this.Ant4img.TabStop = false;
            // 
            // Ant5img
            // 
            this.Ant5img.BackColor = System.Drawing.Color.Transparent;
            this.Ant5img.Image = ((System.Drawing.Image)(resources.GetObject("Ant5img.Image")));
            this.Ant5img.Location = new System.Drawing.Point(43, 229);
            this.Ant5img.Name = "Ant5img";
            this.Ant5img.Size = new System.Drawing.Size(55, 27);
            this.Ant5img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant5img.TabIndex = 7;
            this.Ant5img.TabStop = false;
            // 
            // Ant6img
            // 
            this.Ant6img.BackColor = System.Drawing.Color.Transparent;
            this.Ant6img.Image = ((System.Drawing.Image)(resources.GetObject("Ant6img.Image")));
            this.Ant6img.Location = new System.Drawing.Point(43, 280);
            this.Ant6img.Name = "Ant6img";
            this.Ant6img.Size = new System.Drawing.Size(55, 27);
            this.Ant6img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant6img.TabIndex = 8;
            this.Ant6img.TabStop = false;
            // 
            // Ant7img
            // 
            this.Ant7img.BackColor = System.Drawing.Color.Transparent;
            this.Ant7img.Image = ((System.Drawing.Image)(resources.GetObject("Ant7img.Image")));
            this.Ant7img.Location = new System.Drawing.Point(43, 335);
            this.Ant7img.Name = "Ant7img";
            this.Ant7img.Size = new System.Drawing.Size(55, 27);
            this.Ant7img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant7img.TabIndex = 9;
            this.Ant7img.TabStop = false;
            // 
            // Ant8img
            // 
            this.Ant8img.BackColor = System.Drawing.Color.Transparent;
            this.Ant8img.Image = ((System.Drawing.Image)(resources.GetObject("Ant8img.Image")));
            this.Ant8img.Location = new System.Drawing.Point(43, 385);
            this.Ant8img.Name = "Ant8img";
            this.Ant8img.Size = new System.Drawing.Size(55, 27);
            this.Ant8img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant8img.TabIndex = 10;
            this.Ant8img.TabStop = false;
            // 
            // Ant9img
            // 
            this.Ant9img.BackColor = System.Drawing.Color.Transparent;
            this.Ant9img.Image = ((System.Drawing.Image)(resources.GetObject("Ant9img.Image")));
            this.Ant9img.Location = new System.Drawing.Point(43, 441);
            this.Ant9img.Name = "Ant9img";
            this.Ant9img.Size = new System.Drawing.Size(55, 27);
            this.Ant9img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant9img.TabIndex = 11;
            this.Ant9img.TabStop = false;
            // 
            // Ant10img
            // 
            this.Ant10img.BackColor = System.Drawing.Color.Transparent;
            this.Ant10img.Image = ((System.Drawing.Image)(resources.GetObject("Ant10img.Image")));
            this.Ant10img.Location = new System.Drawing.Point(43, 492);
            this.Ant10img.Name = "Ant10img";
            this.Ant10img.Size = new System.Drawing.Size(55, 27);
            this.Ant10img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ant10img.TabIndex = 12;
            this.Ant10img.TabStop = false;
            // 
            // DeGokkersWidow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 547);
            this.Controls.Add(this.Ant10img);
            this.Controls.Add(this.Ant9img);
            this.Controls.Add(this.Ant8img);
            this.Controls.Add(this.Ant7img);
            this.Controls.Add(this.Ant6img);
            this.Controls.Add(this.Ant5img);
            this.Controls.Add(this.Ant4img);
            this.Controls.Add(this.Ant3img);
            this.Controls.Add(this.Ant2img);
            this.Controls.Add(this.Ant1img);
            this.Controls.Add(this.InfoGroup);
            this.Controls.Add(this.GambleCornerGroup);
            this.Controls.Add(this.Picturebox);
            this.Name = "DeGokkersWidow";
            this.Text = "De Gokkers";
            ((System.ComponentModel.ISupportInitialize)(this.Picturebox)).EndInit();
            this.GambleCornerGroup.ResumeLayout(false);
            this.GambleCornerGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumericAnt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericEuro)).EndInit();
            this.InfoGroup.ResumeLayout(false);
            this.InfoGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ant1img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant2img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant3img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant4img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant5img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant6img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant7img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant8img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant9img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ant10img)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Picturebox;
        private System.Windows.Forms.GroupBox GambleCornerGroup;
        private System.Windows.Forms.Button BetButton;
        private System.Windows.Forms.NumericUpDown NumericAnt;
        private System.Windows.Forms.NumericUpDown NumericEuro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label MinimalLabel;
        private System.Windows.Forms.RadioButton Radiobutton3;
        private System.Windows.Forms.RadioButton Radiobutton2;
        private System.Windows.Forms.RadioButton Radiobutton1;
        private System.Windows.Forms.Label ParticipantsLabel;
        private System.Windows.Forms.GroupBox InfoGroup;
        private System.Windows.Forms.Button GoButton;
        private System.Windows.Forms.Label GamblesLabel;
        private System.Windows.Forms.PictureBox Ant1img;
        private System.Windows.Forms.PictureBox Ant2img;
        private System.Windows.Forms.PictureBox Ant3img;
        private System.Windows.Forms.PictureBox Ant4img;
        private System.Windows.Forms.PictureBox Ant5img;
        private System.Windows.Forms.PictureBox Ant6img;
        private System.Windows.Forms.PictureBox Ant7img;
        private System.Windows.Forms.PictureBox Ant8img;
        private System.Windows.Forms.PictureBox Ant9img;
        private System.Windows.Forms.PictureBox Ant10img;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.TextBox TextBox3;
        private System.Windows.Forms.TextBox TextBox2;
        private System.Windows.Forms.TextBox TextBox1;
    }
}

