﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class DeGokkersWidow : Form
    {
        /*private Guy sietse;
        private Guy elton;
        private Guy fedde;*/

        Guy[] bettors;
        Ant[] ants;
        Guy currentbettor;

        public int winner = 0;
        public int num_winners = 0;

        public DeGokkersWidow()
        {
            InitializeComponent();

            Random randomizer = new Random();

            //initialise alle guys en ants
            bettors = new Guy[3];
            ants = new Ant[10];

            //guys
            bettors[0] = new Guy();
            bettors[0].name = "Sietse";
            bettors[0].myradiobutton = Radiobutton1;
            bettors[0].mytextbox = TextBox1;
            bettors[0].cash = 45;
            bettors[0].UpdateLabels();

            bettors[1] = new Guy();
            bettors[1].name = "Elton";
            bettors[1].myradiobutton = Radiobutton2;
            bettors[1].mytextbox = TextBox2;
            bettors[1].cash = 75;
            bettors[1].UpdateLabels();

            bettors[2] = new Guy();
            bettors[2].name = "Fedde";
            bettors[2].myradiobutton = Radiobutton3;
            bettors[2].mytextbox = TextBox3;
            bettors[2].cash = 50;
            bettors[2].UpdateLabels();

            //Ants
            int startposition = Ant1img.Location.X;
            int distance = Picturebox.Width;
            for (int i = 0; i < 10; i++)
            {
                ants[i] = new Ant();
                ants[i].randomizer = randomizer;
                ants[i].racetracklength = distance;
                ants[i].location = ants[i].startingposition = startposition;
            }

            ants[0].mypicturebox = Ant1img;
            ants[1].mypicturebox = Ant2img;
            ants[2].mypicturebox = Ant3img;
            ants[3].mypicturebox = Ant4img;
            ants[4].mypicturebox = Ant5img;
            ants[5].mypicturebox = Ant6img;
            ants[6].mypicturebox = Ant7img;
            ants[7].mypicturebox = Ant8img;
            ants[8].mypicturebox = Ant9img;
            ants[9].mypicturebox = Ant10img;


            currentbettor = bettors[0];
        }

        private void GoButton_Click(object sender, EventArgs e)
        {

            while (num_winners == 0)
            {
                for (int i = 0; i < ants.Length; i++)
                {
                    if (ants[i].Run())
                    {
                        num_winners++;
                        winner = i + 1;
                    }
                }

                Application.DoEvents();
                System.Threading.Thread.Sleep(3);

            }
                if (num_winners > 1)
                {
                    MessageBox.Show("We hebben " + num_winners + " mieren die hebben gewonnen!!");
                }
                else
                {
                    MessageBox.Show("Mier #" + winner + " heeft gewonnen!!");
                }

                for (int i = 0; i < ants.Length; i++)
                {
                    ants[i].TakeStartingPosition();
                }

                for (int i = 0; i < bettors.Length; i++)
                {
                    bettors[i].Collect(winner);
                    bettors[i].ClearBet();
                    bettors[i].UpdateLabels();
                }

                NumericEuro.Value = NumericEuro.Minimum;
                NumericAnt.Value = NumericAnt.Minimum;
            

            
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            SetBettor(0);
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            SetBettor(1);
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            SetBettor(2);
        }

        private void BetButton_Click(object sender, EventArgs e)
        {
            currentbettor.PlaceBet((int)NumericEuro.Value, (int)NumericAnt.Value);
            currentbettor.UpdateLabels();
        }

        private void SetBettor(int index)
        {
            currentbettor = bettors[index];
            Label1.Text = currentbettor.name;
            if (currentbettor.mybet != null)
            {
                NumericEuro.Value = currentbettor.mybet.amount;
                NumericAnt.Value = currentbettor.mybet.ant;
            }
            else
            {
                NumericEuro.Value = NumericEuro.Minimum;
                NumericAnt.Value = 1;
            }
        }

        private void Form1_load(object sender, EventArgs e)
        {
            MinimalLabel.Text = "Minimale bod is €5";
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            winner = 0;
            num_winners = 0;

            Ant1img.Location = new Point(50, 25);
            Ant2img.Location = new Point(50, 75);
            Ant3img.Location = new Point(50, 125);
            Ant4img.Location = new Point(50, 175);
            Ant5img.Location = new Point(50, 225);
            Ant6img.Location = new Point(50, 280);
            Ant7img.Location = new Point(50, 330);
            Ant8img.Location = new Point(50, 380);
            Ant9img.Location = new Point(50, 435);
            Ant10img.Location = new Point(50, 485);
        }
    }



}
